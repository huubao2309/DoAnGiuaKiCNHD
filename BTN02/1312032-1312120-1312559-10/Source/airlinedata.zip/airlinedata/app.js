var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var morgan = require('morgan');
var mongoose = require('mongoose');

var jwt    = require('jsonwebtoken'); // used to create, sign, and verify tokens
var config = require('./config'); // get our config file
var User   = require('./models/user'); // get our mongoose model

app.use(express.static(__dirname+'/client'));
//app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

Airport = require('./models/airport');
Flight = require('./models/flight');
Booking = require('./models/booking');
FlightDetail = require('./models/flightdetail');
Passenger = require('./models/passenger');

//Connect to Mongoose
mongoose.connect('mongodb://localhost/mydataairline');
var db = mongoose.connection;
app.set('superSecret', config.secret); // secret variable

app.get('/', function(req, res){
	res.send('Hello!! <br/> Please use the following Api: <br/> /api/airports : GET list of Airports. <br/> /api/flights : GET list of Flights. <br/> /api/bookings : GET list of Bookings. <br/> /api/flightdetails : GET list of Flights Detail. <br/> /api/passengers : GET list of Passengers.');
});

app.get('/api/airports', function(req, res){
	Airport.getAirports(function(err, airports) {
		if(err){
			throw err;
		}
		res.json(airports);
	});
});

app.get('/api/flights', function(req, res){
	Flight.getFlights(function(err, flights) {
		if(err){
			throw err;
		}
		res.json(flights);
	});
});

app.get('/api/flights/:_id', function(req, res){
	Flight.getFlight(req.params._id, function(err, flight) {
		if(err){
			throw err;
		}
		res.json(flight);
	});
});

app.get('/api/flights/:sta_id', function(req, res){
	Flight.getFlightById(req.params.sta_id, function(err, flights) {
		if(err){
			throw err;
		}
		res.json(flights);
	});
});

app.post('/api/flights', function(req, res){
	var flight = req.body;
	Flight.addFlight({}, flight, function(err, flight) {
		if(err){
			throw err;
		}
		res.json(flight);
	});
});

app.get('/api/bookings', function(req, res){
	Booking.getBookings(function(err, booking) {
		if(err){
			throw err;
		}
		res.json(booking);
	});
});

app.post('/api/bookings', function(req, res){
	var booking = req.body;
	Booking.addBooking(booking, function(err, booking) {
		if(err){
			throw err;
		}
		res.json(booking);
	});
});

app.put('/api/bookings/:boo_id', function(req, res){
	var booking = req.body;
	Booking.updateBooking(req.params.boo_id, booking, {}, function(err, booking) {
		if(err){
			throw err;
		}
		res.json(booking);
	});

});

app.get('/api/flightdetails', function(req, res){
	FlightDetail.getFlightDetail(function(err, flightdetail) {
		if(err){
			throw err;
		}
		res.json(flightdetail);
	});
});

app.post('/api/flightdetails', function(req, res){
	var flightdetail = req.body;
	FlightDetail.addFlightDetail(flightdetail, function(err, flightdetail) {
		if(err){
			throw err;
		}
		res.json(flightdetail);
	});
});

app.get('/api/flightdetails/:boo_id', function(req, res){
	FlightDetail.getFlightDetailById(req.params.boo_id, function(err, flightdetails) {
		if(err){
			throw err;
		}
		res.json(flightdetails);
	});
});

app.get('/api/passengers', function(req, res){
	Passenger.getPassengers(function(err, passengers) {
		if(err){
			throw err;
		}
		res.json(passengers);
	});
});

app.post('/api/passengers', function(req, res){
	var passenger = req.body;
	Passenger.addPassenger(passenger, function(err, passenger) {
		if(err){
			throw err;
		}
		res.json(passenger);
	});
});


// use morgan to log requests to the console
app.use(morgan('dev'));

// =================================================================
// routes ==========================================================
// =================================================================
app.get('/setup', function(req, res) {

	// create a sample user
	var nick = new User({ 
		name: 'Ha Minh Dat', 
		password: '123456',
		admin: true 
	});
	nick.save(function(err) {
		if (err) throw err;

		console.log('User saved successfully');
		res.json({ success: true });
	});
});

app.post('/api/users', function(req, res) {

	var user = req.body;
	User.addUser(user, function(err, user) {
		if(err){
			throw err;
		}
		res.json(user);
	});
});

// ---------------------------------------------------------
// get an instance of the router for api routes
// ---------------------------------------------------------
var apiRoutes = express.Router(); 

// ---------------------------------------------------------
// authentication (no middleware necessary since this isnt authenticated)
// ---------------------------------------------------------
// http://localhost:3000/api/authenticate
apiRoutes.post('/authenticate', function(req, res) {

	// find the user
	User.findOne({
		name: req.body.name
	}, function(err, user) {

		if (err) throw err;

		if (!user) {
			res.json({ success: false, message: 'Authentication failed. User not found.' });
		} else if (user) {

			// check if password matches
			if (user.password != req.body.password) {
				res.json({ success: false, message: 'Authentication failed. Wrong password.' });
			} else {

				// if user is found and password is right
				// create a token
				var token = jwt.sign(user, app.get('superSecret'), {
					expiresIn: 86400 // expires in 24 hours
				});

				res.json({
					success: true,
					message: 'Enjoy your token!',
					token: token
				});
			}		

		}

	});
});

// ---------------------------------------------------------
// route middleware to authenticate and check token
// ---------------------------------------------------------
apiRoutes.use(function(req, res, next) {

	// check header or url parameters or post parameters for token
	var token = req.body.token || req.param('token') || req.headers['x-access-token'];

	// decode token
	if (token) {

		// verifies secret and checks exp
		jwt.verify(token, app.get('superSecret'), function(err, decoded) {			
			if (err) {
				return res.json({ success: false, message: 'Failed to authenticate token.' });		
			} else {
				// if everything is good, save to request for use in other routes
				req.decoded = decoded;	
				next();
			}
		});

	} else {

		// if there is no token
		// return an error
		return res.status(403).send({ 
			success: false, 
			message: 'No token provided.'
		});
		
	}
	
});

// ---------------------------------------------------------
// authenticated routes
// ---------------------------------------------------------
apiRoutes.get('/', function(req, res) {
	res.json({ message: 'Welcome to the coolest API on earth!' });
});

apiRoutes.get('/users', function(req, res) {
	User.find({}, function(err, users) {
		res.json(users);
	});
});



apiRoutes.get('/check', function(req, res) {
	res.json(req.decoded);
});

app.use('/api', apiRoutes);

app.listen(3000);
console.log('Running on port 3000...');
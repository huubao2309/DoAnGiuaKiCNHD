var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// set up a mongoose model
var User = module.exports = mongoose.model('User', new Schema({ 
	name: String, 
	password: String, 
	admin: Boolean 
}));

// Post Flight
module.exports.addUser = function(user, callback){
	User.create(user, callback);
}

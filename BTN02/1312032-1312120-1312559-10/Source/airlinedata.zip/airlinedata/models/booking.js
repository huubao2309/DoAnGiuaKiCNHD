var mongoose = require('mongoose');

// Booking Schema
var bookingSchema = mongoose.Schema({
	boo_id:{
		type: String,
		required: true
	},
	datetime:{
		type: Date
	},
	price:{
		type: String,
		required: true
	},
	status:{
		type: String,
		required: true
	}
});

var Booking = module.exports = mongoose.model('Booking', bookingSchema);

// Get Bookings
module.exports.getBookings = function(callback, limit){
	Booking.find(callback).limit(limit);
}

// Post Booking
module.exports.addBooking = function(booking, callback){
	Booking.create(booking, callback);
}

// Put Booking
module.exports.updateBooking = function(_id, booking, options, callback){
	var query = {boo_id: _id};
	var update = {
		boo_id: booking.boo_id,
		datetime: booking.datetime,
		price: booking.price,
		status: booking.status

	}
	Booking.findOneAndUpdate(query, update, options, callback);

}
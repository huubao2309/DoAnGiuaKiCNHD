var mongoose = require('mongoose');

// FlightDetail Schema
var flightdetailSchema = mongoose.Schema({
	boo_id:{
		type: String,
		required: true
	},
	fli_id:{
		type: String,
		required: true
	},
	date:{
		type: Date
	},
	rank:{
		type: String,
		required: true
	},
	sale:{
		type: String
	},
});

var FlightDetail = module.exports = mongoose.model('FlightDetail', flightdetailSchema);

// Get FlightDetails
module.exports.getFlightDetail = function(callback, limit){
	FlightDetail.find(callback).limit(limit);
}

// Post FlightDetail
module.exports.addFlightDetail = function(flightdetail, callback){
	FlightDetail.create(flightdetail, callback);
}

// Get FlightDetail
module.exports.getFlightDetailById = function(_id, callback){
	var query = {boo_id: _id};
	FlightDetail.find(query, callback);
}
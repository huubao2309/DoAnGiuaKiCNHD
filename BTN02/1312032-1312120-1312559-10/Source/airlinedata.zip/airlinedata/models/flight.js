var mongoose = require('mongoose');

// Flight Schema
var flightSchema = mongoose.Schema({
	fli_id:{
		type: String,
		required: true
	},
	sta_id:{
		type: String,
		required: true
	},
	des_id:{
		type: String,
		required: true
	},
	date:{
		type: Date
	},
	time:{
		type: String,
		required: true
	},
	rank:{
		type: String,
		required: true
	},
	sale:{
		type: String,
		required: true
	},
	amount:{
		type: String,
		required: true
	},
	price:{
		type: String,
		required: true
	}
});

var Flight = module.exports = mongoose.model('Flight', flightSchema);

// Get Flights
module.exports.getFlights = function(callback, limit){
	Flight.find(callback).limit(limit);
}

// Get Flight with id
module.exports.getFlight = function(id, callback){
	Flight.findById(id, callback);
}

// Get Flights with id airport start
module.exports.getFlightById = function(_id, callback){
	var query = {sta_id: _id};
	Flight.find(query, callback);
}

// Post Flight
module.exports.addFlight = function(flight, callback){
	Flight.create(flight, callback);
}

var mongoose = require('mongoose');

// Airport Schema
var airportSchema = mongoose.Schema({
	code:{
		type: String,
		required: true
	},
	name:{
		type: String,
		required: true
	},
	create_date:{
		type: Date,
		default: Date.now
	}
});

var Airport = module.exports = mongoose.model('Airport', airportSchema);

// Get Airports
module.exports.getAirports = function(callback, limit){
	Airport.find(callback).limit(limit);
}

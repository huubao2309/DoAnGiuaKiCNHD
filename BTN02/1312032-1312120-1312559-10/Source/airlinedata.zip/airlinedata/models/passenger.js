var mongoose = require('mongoose');

// Passenger Schema
var passengerSchema = mongoose.Schema({
	boo_id : {
		type: String,
		required: true
	},
	named : {
		type: String,
		required: true
	},
	lname : {
		type: String,
		required: true
	},
	fname : {
		type: String,
		required: true
	}
});

var Passenger = module.exports = mongoose.model('Passenger', passengerSchema);

// Get Passenger
module.exports.getPassengers = function(callback, limit){
	Passenger.find(callback).limit(limit);
}

// Post Passenger
module.exports.addPassenger = function(passenger, callback){
	Passenger.create(passenger, callback);
}

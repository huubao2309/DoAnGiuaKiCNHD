var myApp = angular.module('myApp', ['ngRoute']);

myApp.config(function($routeProvider){
	$routeProvider.when('/', {
		controller: 'FlightsController',
		templateUrl: 'views/flight.html'
	})
	.when('/flights', {
		controller: 'FlightsController',
		templateUrl: 'views/flight.html'
	})
	.when('/bookings/:id', {
		controller: 'FlightsController',
		templateUrl: 'views/comfirm_booking.html'
	})
	.when('/booking', {
		controller: 'FlightsController',
		templateUrl: 'views/booking.html'
	})
	.otherwise({
		redirectTo: '/'
	});
});
var myApp = angular.module('myApp');

myApp.service('mService', function() {
  var tabID = 1;
  var objectValue = {
        data: 1
    };

  return {
        getTabID: function() {
            return tabID;
        },
        setTabID: function(value) {
            tabID = value;
        },
        getObject: function() {
            return objectValue;
        }
    }

});

myApp.controller('FlightsController', ['$scope', '$http', '$location', '$routeParams', 'mService', function($scope, $http, $location, $routeParams, mService) {
	console.log('FlightsController loaded...');

	$scope.getFlights = function(){
		$http.get('/api/flights').success(function(response){
			$scope.flights = response;
		});
	}

	$scope.getFlight = function(){
		var id = $routeParams.id;
		$http.get('/api/flights/'+id).success(function(response){
			$scope.flight = response;
		});
	}

	$scope.addBooking = function(){
		var txtId = "";
	    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

	    for( var i=0; i < 6; i++ )
	        txtId += possible.charAt(Math.floor(Math.random() * possible.length));
		$scope.booking = {};
		$scope.booking.boo_id = txtId;
		$scope.booking.datetime = $scope.flight.date;
		$scope.booking.price = '' + $scope.flight.price;
		$scope.booking.status = "0";
		console.log($scope.booking);
		$http.post('/api/bookings/', $scope.booking).success(function(response){
			$scope.flightdetail = {};
			$scope.flightdetail.boo_id = txtId;
			$scope.flightdetail.fli_id = '' + $scope.flight.fli_id;
			$scope.flightdetail.date = $scope.flight.date;
			$scope.flightdetail.rank = '' + $scope.flight.rank;
			$scope.flightdetail.sale = '' + $scope.flight.sale;
			console.log($scope.flightdetail);
			$http.post('/api/flightdetails/', $scope.flightdetail).success(function(response){
				window.location.href='#/flights';
			});
		});
	}

	/*$scope.booking = function(){
		
	}*/

	$scope.getAirports = function(){
		$http.get('/api/airports').success(function(response){
			$scope.airports = response;
		});
	}

	$scope.searchBooking = function(){
		
		$http.get('/api/flights').success(function(response){
			$scope.lflights = response;
			$scope.lsmotchieu = [];
			$scope.lskhuhoi =[];

			$scope.lflights.forEach(function(val, key){
								
				$scope.obj1 = {
					fli_id: val.fli_id,
					sta_id: val.sta_id,
					des_id: val.des_id,
					date: val.date,
					time: val.time,
					rank: val.rank,
					sale: val.sale,
					amount: val.amount,
					price: val.price
				};		

				var id1 = $scope.staAP[1] + $scope.staAP[2] + $scope.staAP[3];
				var id2 = $scope.desAP[1] + $scope.desAP[2] + $scope.desAP[3];

				$scope.obj2 = {
					fli_id: val.fli_id,
					sta_id: id1,
					des_id: id2,
					date: val.date,
					time: val.time,
					rank: val.rank,
					sale: val.sale,
					amount: val.amount,
					price: val.price
				};

				if (angular.equals($scope.obj1, $scope.obj2) === true) {
						$scope.lsmotchieu.push(obj1);
				} else {
					console.log('fail');
				}		
			});
		});
		
	}

}]);

myApp.controller('TabController', ['$scope', 'mService', function($scope, mService) {
	var id = 1;
	$scope.panel.activeTab = 1;
	$scope.panel.setTab = function(tabId) {
		$scope.panel.activeTab = tabId;
		id = $scope.panel.activeTab;
		mService.setTabID(id);
	};
	
}]);